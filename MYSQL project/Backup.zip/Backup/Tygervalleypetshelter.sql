-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: tygervalleypetshelter
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `category_ID` int NOT NULL AUTO_INCREMENT,
  `category_Name` varchar(45) NOT NULL,
  `pet_ID` int NOT NULL,
  PRIMARY KEY (`category_ID`),
  KEY `pet_ID` (`pet_ID`),
  KEY `category_Name_Index` (`category_Name`),
  CONSTRAINT `category_ibfk_1` FOREIGN KEY (`pet_ID`) REFERENCES `pets` (`pet_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Mammal',1),(2,'Bird',2),(3,'Mammal',3),(4,'Bird',4),(5,'Reptile',5);
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `company`
--

DROP TABLE IF EXISTS `company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `company` (
  `company_ID` int NOT NULL AUTO_INCREMENT,
  `company_Name` varchar(45) NOT NULL,
  `contact_Number` varchar(10) NOT NULL,
  `email` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`company_ID`),
  KEY `company_Name_Index` (`company_Name`),
  CONSTRAINT `company_chk_1` CHECK ((`email` like _utf8mb4'%_@_%._%'))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company`
--

LOCK TABLES `company` WRITE;
/*!40000 ALTER TABLE `company` DISABLE KEYS */;
INSERT INTO `company` VALUES (1,'Pellet Paradise','0734271817','pelletp@gmail.com'),(2,'Seed Land','0728769045','seedLand@gmail.com'),(3,'Vegetables for you','0821234567','vegetables4u@gmail.com'),(4,'Pet Biscuits','0626342890','petbiscuits@gmail.com'),(5,'Billies butchery','0834568902','billiesb@gmail.com');
/*!40000 ALTER TABLE `company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `foodallocation`
--

DROP TABLE IF EXISTS `foodallocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `foodallocation` (
  `food_ID` int NOT NULL,
  `category_ID` int NOT NULL,
  `food_Quantity` int NOT NULL,
  `measurement_Unit` varchar(45) NOT NULL DEFAULT 'Grams',
  PRIMARY KEY (`food_ID`,`category_ID`),
  KEY `category_ID` (`category_ID`),
  KEY `food_Quantity_Index` (`food_Quantity`),
  CONSTRAINT `foodallocation_ibfk_1` FOREIGN KEY (`food_ID`) REFERENCES `petfood` (`food_ID`),
  CONSTRAINT `foodallocation_ibfk_2` FOREIGN KEY (`category_ID`) REFERENCES `category` (`category_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `foodallocation`
--

LOCK TABLES `foodallocation` WRITE;
/*!40000 ALTER TABLE `foodallocation` DISABLE KEYS */;
INSERT INTO `foodallocation` VALUES (1,1,60,'Grams'),(3,3,90,'Grams'),(4,4,50,'Grams'),(5,5,120,'Grams');
/*!40000 ALTER TABLE `foodallocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `petfood`
--

DROP TABLE IF EXISTS `petfood`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `petfood` (
  `food_ID` int NOT NULL AUTO_INCREMENT,
  `food_Type` varchar(45) NOT NULL,
  `expiry_Date` date NOT NULL,
  `company_ID` int NOT NULL,
  PRIMARY KEY (`food_ID`),
  KEY `company_ID` (`company_ID`),
  KEY `food_Type_Index` (`food_Type`),
  CONSTRAINT `petfood_ibfk_1` FOREIGN KEY (`company_ID`) REFERENCES `company` (`company_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `petfood`
--

LOCK TABLES `petfood` WRITE;
/*!40000 ALTER TABLE `petfood` DISABLE KEYS */;
INSERT INTO `petfood` VALUES (1,'Pellets','2023-09-12',1),(3,'Vegetables','2023-06-07',3),(4,'Biscuits','2023-08-16',4),(5,'Meats','2023-01-23',5);
/*!40000 ALTER TABLE `petfood` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pets`
--

DROP TABLE IF EXISTS `pets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pets` (
  `pet_ID` int NOT NULL AUTO_INCREMENT,
  `pet_Type` varchar(45) NOT NULL,
  `num_Of_Pets` int NOT NULL,
  PRIMARY KEY (`pet_ID`),
  UNIQUE KEY `pet_Type` (`pet_Type`),
  KEY `pet_Type_Index` (`pet_Type`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pets`
--

LOCK TABLES `pets` WRITE;
/*!40000 ALTER TABLE `pets` DISABLE KEYS */;
INSERT INTO `pets` VALUES (1,'Dog',29),(2,'Parrot',25),(3,'Cat',27),(4,'Budgie',11),(5,'Snakes',22),(6,'Hamster',9);
/*!40000 ALTER TABLE `pets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `vw_expiredfooddetails`
--

DROP TABLE IF EXISTS `vw_expiredfooddetails`;
/*!50001 DROP VIEW IF EXISTS `vw_expiredfooddetails`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_expiredfooddetails` AS SELECT 
 1 AS `company_ID`,
 1 AS `company_Name`,
 1 AS `contact_Number`,
 1 AS `food_ID`,
 1 AS `food_Type`,
 1 AS `expiry_Date`,
 1 AS `food_Quantity`,
 1 AS `measurement_Unit`,
 1 AS `category_ID`,
 1 AS `category_Name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vw_lowestfoods`
--

DROP TABLE IF EXISTS `vw_lowestfoods`;
/*!50001 DROP VIEW IF EXISTS `vw_lowestfoods`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_lowestfoods` AS SELECT 
 1 AS `category_Name`,
 1 AS `Lowest Number of Pets`,
 1 AS `pet_ID`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vw_manufacturerdetails`
--

DROP TABLE IF EXISTS `vw_manufacturerdetails`;
/*!50001 DROP VIEW IF EXISTS `vw_manufacturerdetails`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_manufacturerdetails` AS SELECT 
 1 AS `company_ID`,
 1 AS `company_Name`,
 1 AS `contact_Number`,
 1 AS `food_ID`,
 1 AS `food_Type`,
 1 AS `food_Quantity`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vw_petspertype`
--

DROP TABLE IF EXISTS `vw_petspertype`;
/*!50001 DROP VIEW IF EXISTS `vw_petspertype`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_petspertype` AS SELECT 
 1 AS `pet_ID`,
 1 AS `pet_Type`,
 1 AS `Total Number of Pets`,
 1 AS `category_ID`,
 1 AS `category_Name`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `vw_expiredfooddetails`
--

/*!50001 DROP VIEW IF EXISTS `vw_expiredfooddetails`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_expiredfooddetails` AS select `company`.`company_ID` AS `company_ID`,`company`.`company_Name` AS `company_Name`,`company`.`contact_Number` AS `contact_Number`,`petfood`.`food_ID` AS `food_ID`,`petfood`.`food_Type` AS `food_Type`,`petfood`.`expiry_Date` AS `expiry_Date`,`foodallocation`.`food_Quantity` AS `food_Quantity`,`foodallocation`.`measurement_Unit` AS `measurement_Unit`,`category`.`category_ID` AS `category_ID`,`category`.`category_Name` AS `category_Name` from (((`company` join `petfood` on((`company`.`company_ID` = `petfood`.`company_ID`))) join `foodallocation` on((`petfood`.`food_ID` = `foodallocation`.`food_ID`))) join `category` on((`foodallocation`.`category_ID` = `category`.`category_ID`))) where (curdate() > `petfood`.`expiry_Date`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_lowestfoods`
--

/*!50001 DROP VIEW IF EXISTS `vw_lowestfoods`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_lowestfoods` AS select `category`.`category_Name` AS `category_Name`,sum(`pets`.`num_Of_Pets`) AS `Lowest Number of Pets`,`pets`.`pet_ID` AS `pet_ID` from (`category` join `pets` on((`pets`.`pet_ID` = `category`.`pet_ID`))) group by `category`.`category_Name`,`pets`.`pet_ID` order by `pets`.`num_Of_Pets` limit 3 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_manufacturerdetails`
--

/*!50001 DROP VIEW IF EXISTS `vw_manufacturerdetails`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_manufacturerdetails` AS select `company`.`company_ID` AS `company_ID`,`company`.`company_Name` AS `company_Name`,`company`.`contact_Number` AS `contact_Number`,`petfood`.`food_ID` AS `food_ID`,`petfood`.`food_Type` AS `food_Type`,`foodallocation`.`food_Quantity` AS `food_Quantity` from ((`company` join `petfood` on((`company`.`company_ID` = `petfood`.`company_ID`))) join `foodallocation` on((`petfood`.`food_ID` = `foodallocation`.`food_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_petspertype`
--

/*!50001 DROP VIEW IF EXISTS `vw_petspertype`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_petspertype` AS select `pets`.`pet_ID` AS `pet_ID`,`pets`.`pet_Type` AS `pet_Type`,sum(`pets`.`num_Of_Pets`) AS `Total Number of Pets`,`category`.`category_ID` AS `category_ID`,`category`.`category_Name` AS `category_Name` from (`pets` join `category` on((`pets`.`pet_ID` = `category`.`pet_ID`))) group by `pets`.`pet_ID`,`category`.`category_ID` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-02 13:35:18
